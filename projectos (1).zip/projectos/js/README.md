# Minecraft
All the files for the YouTube 3d Minecraft tutorial are located here!

Hey! You can download the latest code from the series from here. 
Download the whole repository as a zip or just as a folder. 
If you download it as a ZIP, you will need to extract it.
Then, just open the folder and click on the 3dminecraft.html to open the minecraft program :)
Oh and make sure to open the minecraft.html file as a server!

If you have any questions, please ask either here or in youtube.

Find me in youtube at Hritik RC (https://www.youtube.com/channel/UCcGIeUrE5IpTHk9S2R_l0uQ?view_as=subscriber)

Thanks for the support! :)
